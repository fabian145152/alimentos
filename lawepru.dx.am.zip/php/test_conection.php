<?php
/*
include_once '../includes/db.php';
$con=openCon();
echo("todo ok");
closeCon($con);
echo(" desconectado");
*/

?>
